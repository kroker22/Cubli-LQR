%% 12월 8일 기준으로 코드 정리중

clc 
clear all
close all 

%% parameter setting

%% 문제 2, 3
syms S K1 K2 K3 l1 l2 l3 Ki1 Ki2 Ki3 Ki4 Lii

i = [1 1 1];
I= diag(i);
L= 0.085;
Lb = 0.075;
Mb = 0.419;
Mw = 0.204;
Ib = 3.34*10^-3;
Iw = 0.57*10^-3;
Cb = 1.02*10^-32;
Cw = 0.05*10^-3;
Km = 25.1*10^-3;
g = 9.8;

%%DC Motor
Ra = 1.76;
La = 0.000658;
Kt = 0.0683;
Ke = Kt;
J = 0.00000995;
t=0.00376;
b = J/t;
Va = 48;


A21 = (Mb*Lb+Mw*L)*g/(Ib+Mw*L^2);
A22 = -Cb/(Ib+Mw*L^2);
A23 = Cw/(Ib+Mw*L^2);
A31 =-(Mb*Ib+Mw*L)*g/(Ib+Mw*L^2);
A32 = Cb/(Ib+Mw*L^2);
A33 = -Cw*((Ib+Iw+Mw*L^2))/(Iw*(Ib+Mw*L^2));

B2 =-Km/(Ib+Mw*L^2);
B3 =Km*(Ib+Iw+Mw*L^2)/(Iw*(Ib+Mw*L^2));

F = [0 1 0;
    A21 A22 A23;
    A31 A32 A33];

G = [0;B2;B3];

H = [1 0 0];
J = 0;
state_space = ss(F,G,H,J);
x0 = [1 1 1];
x1 = [1  0 0];
%% desired poles

desired_pole = [-1.242 + 1.302j;
                -1.242 - 1.302j;
                      -30     ];

SRL_desired_pole = [-11.541+5.54i;-11.541-5.54i;-100];  % rootlocus에서 적당히 구함
%  desired sys_pole
% dominant pole
estimator_desired_pole     =      5*desired_pole; 
%symmetric root locus 
SRL_estimator_desired_pole =     2*SRL_desired_pole; 

%% 문제 4,5-a,5-b
s = tf('s'); % 대문자 S는 syms, s는 전달함수 변수

sys_zero = det([S*I-F -G; ...
                H  J]);

sys_zero = solve(sys_zero,S);
sys_pole = det(S*I-F);
sys_pole = solve(sys_pole,S);

z = vpa(sys_zero,5);
p = vpa([sys_pole(1) sys_pole(2) sys_pole(3)],5);
% z,p 값으로 만든 plant 전달함수
G_s = (s-7.0703e-18)/((s+0.094114)*(s-9.9617)*(s+9.9657));
%% Ackerman formula
desired_pole = [-1.242 + 1.302j;
                -1.242 - 1.302j;
                      -30     ];
 %계수 확인용
Acker = (s-desired_pole(1))*(s-desired_pole(2))*(s-desired_pole(3));

acker1 = 32.484;
acker2 = 77.758;
acker3 = 97.133;

acker_ = F^3            + ...
         acker1 * F^2   + ...
         acker2 * F     + ...
         acker3 * I     ;

Cc=[G F*G F*F*G];

K_ackerman = [0 0 1]*inv(Cc)*acker_;
K_ackerman2 = acker(F,G,desired_pole);
state_space_ack = ss(F-G*K_ackerman2,G, H, J);

% %
% figure(1)
% initial(state_space_ack,x0);
% ylabel("radians"); 
% xlabel("Time(s)");
% grid on;

% figure(2)
% rlocus(G_s);
% figure(3)
% rlocus(Acker);

%% SRL
%G_s = (s-7.0703e-18)/((s+0.094114)*(s-9.9617)*(s+9.9657))

G_o_plus = (s-7.0703e-18)/((s+0.094114)*(s-9.9617)*(s+9.9657));
G_o_minus = (-s+7.0703e-18)/((-s+0.094114)*(-s-9.9617)*(-s+9.9657));

%2개는 desired pole의 5배

k_srl  = place(F, G, SRL_desired_pole);
state_space_k_srl = ss(F-G*k_srl, G , H, J);

%% 6-a) closed loop estimator, observer canonical form
% system matrix --> F = F', G = [b1, b2 ,b3]' = H', H = [1 0 0]

F_o = F';
G_o = H.';
H_o = G.';


%observabillity
O = [   H;
        H * F;
        H * F^2 ] ;
L = [l1 l2 l3]';

%계수 확인용
Acker_O = (s-estimator_desired_pole(1))*(s-estimator_desired_pole(2))*(s-estimator_desired_pole(3));
acker1_o = 162.4;
acker2_o = 1944;
acker3_o = 1.214e04;

acker_O = F^3            + ...
          acker1_o * F^2 + ...
          acker2_o * F   + ...
          acker3_o * I   ;

L_ackerman = acker_O * inv(O) * [ 0;
                                  0;
                                  1  ];
L_ackerman2 = acker(F_o, G_o, estimator_desired_pole);

det_o = det(O);

%% Make LQR   -- LQR VS SRL VS Ackerman

rho = 16140;
Q = rho * H' * H;
R = 1;

LQR_K = lqr(F,G,Q,R);

state_space_LQR = ss(F-G*LQR_K, G, H, J );
lqr_pole = pole(state_space_LQR);
figure(3)
hold on
initial(state_space_LQR,x0);
initial(state_space_k_srl,x0);
initial(state_space_ack,x0);

legend("LQR", "NORMAL_SRL","Akerman","original system");
title("Initial Graph -- state space");
xlabel("Time(s)");
ylabel("theta(degrees)");
grid on

%% Rho 값에 따라 바뀌는 LQR 그래프 변화 확인 rho_0 = 1  rho_1 = 10 rho_2 = 1000
rho_0 = 1;   rho_1 = 100; rho_2 = 16140;

Q_0 =rho_0 * H' * H;       Q_1 = rho_1 * H' * H;       Q_2 = rho_2 * H' * H;

LQR_K0 = lqr(F,G,Q_0, R);    LQR_K1 = lqr(F,G,Q_1,R);   LQR_K2 = lqr(F,G,Q_2,R);

state_space_LQR_0 = ss(F-G*LQR_K0, G, H, J);
state_space_LQR_1 = ss(F-G*LQR_K1, G, H,J);
state_space_LQR_2 = ss(F-G*LQR_K2, G, H,J);

figure(4)
hold on
initial(state_space_LQR_0,x0);
initial(state_space_LQR_1,x0);
initial(state_space_LQR_2,x0);
legend("rho = 1", "rho = 100","rho = 16104");
title("Initial Graph -- Cost function");
xlabel("Time(s)");
ylabel("theta(degrees)");
grid on

%%  6-b) full order estimator SRL
SRL_estimator_pole_poly = (s-2*SRL_desired_pole(1))*(s-2*SRL_desired_pole(2))*(s-2*SRL_desired_pole(3));
SRL_L_0 = place(F,G,SRL_desired_pole);

est_SRL_L = place(F_o,G_o,SRL_estimator_desired_pole);

estimator_SRL_acker1 = 246.2;
estimator_SRL_acker2 = 9888;
estimator_SRL_acker3 = 131100;

estimator_SRL_acker = F^3 + ... 
                      estimator_SRL_acker1 * F^2 + ...
                      estimator_SRL_acker2 * F   + ...
                      estimator_SRL_acker1 * I;

SRL_L = estimator_SRL_acker * inv(O) * [0;0;1];

%% estimator overall 
K_est = K_ackerman;
L_est = L_ackerman;

%F_estimator = vpa((F-G*K_est-L_est*H),5);
%(F-GK-LH)x_hat
F_estimator =F-L_est*H; 

%G_estimator = vpa(L_est,5); 
%Ly (y = input)
G_estimator= L_est;

%H_estimator = vpa(-K_est,5);
%u = x_hat(t) (u = output)
H_estimator = -K_est; 

%J = 0
D_estimator = 0;

sys_est = ss(F_estimator,G_estimator,H_estimator,D_estimator);

zero_est = det([S*I-F_estimator -G_estimator; ...
                H_estimator  0]);


zero_est = vpa(solve(zero_est,S),5);
pole_est = det(S*I-F_estimator);
pole_est = vpa(solve(pole_est,S),5);


% 
% figure(6)
% hold on;
% initial(sys_est,x0);
% initial(state_space_ack,x0);
% initial(state_space_srl, x0);
% xlabel("Time(s)");
% ylabel("radians");
% legend("estimate","ackerman", "SRL");

D_s_est=(s+8.5493)*(s-3.4516)/((s+1.2707)*(s+63.599+78.452i)*(s+63.599-78.452i));% estimator 전달함수
%% reference input matirx
reference_input_matrix = [F G; H J];
Nx1 = 1;
Nx2 = 0;
Nxu = solve((-B2*S-A21)/A23+(B3*S-A31)/A33,S);
Nx3 = (-B2*Nxu-A21)/A23;
N_bar = vpa((Nxu+ K_ackerman2(1)+K_ackerman2(3)*Nx3),3);
%NxNr= inv([F G;H J])*[0;0;0;1];
%N_bar = NxNr(4) + K_ackerman*([NxNr(1);NxNr(2);NxNr(3)]);
%poly([1.2707 63.599+78.452i s+63.599-78.452i])

%D_c = vpa(-K*inv(S*I-F+G*K+L*H)*L,3) 
%% 문제 8
SRL_desired_pole;
(s-SRL_desired_pole(1))*(s-SRL_desired_pole(2))*(s-SRL_desired_pole(3))
(s-2*SRL_desired_pole(1))*(s-2*SRL_desired_pole(2))*(s-2*SRL_desired_pole(3))
Ki = [Ki1 ,Ki2 ,Ki3, Ki4];
Li = [Lii ;Lii ;Lii];
I = eye(4);
M =[0;0;0]
integral_contorl_matrix = (S*I-[M F;0 H]+[0;G]*Ki) % SRL_desired_pole 1,2는 허수가 나와서 3만 써야할듯
%K_i = vpa(solve(det(integral_contorl_matrix),Kii),3);
K_i = 2.27;
I = eye(3);
est_integral_control_matrix = (S*I-F+Li*H);
L_i = vpa(solve(det(est_integral_control_matrix),Lii),3);
L_i = 201;